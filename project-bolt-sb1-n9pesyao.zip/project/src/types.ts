export interface FormData {
  name: string;
  dob: string;
}

export interface FormResponse {
  success: boolean;
  data: FormData;
}